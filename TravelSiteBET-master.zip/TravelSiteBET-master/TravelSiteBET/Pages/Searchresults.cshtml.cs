using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TravelSiteBET.Pages
{
    public class SearchresultsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
